#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// Encrypt or decrypt a source string using the provided key.
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key to use in encryption / decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key) {
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i) {
        output[i] = source[i] ^ key[i % key_length];
    }

    // Our output length must equal our source length
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Read file content as a string.
/// </summary>
/// <param name="filename">Name of the file to read</param>
/// <returns>File content as a string</returns>
std::string read_file(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return "";
    }

    std::ostringstream buffer;
    buffer << file.rdbuf(); // Read entire file into string
    return buffer.str();
}

/// <summary>
/// Extract the student's name from the input data.
/// </summary>
/// <param name="string_data">Input string data</param>
/// <returns>Extracted student name</returns>
std::string get_student_name(const std::string& string_data) {
    std::string student_name;

    size_t pos = string_data.find('\n');
    if (pos != std::string::npos) {
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

/// <summary>
/// Save encrypted or decrypted data to a file.
/// </summary>
/// <param name="filename">Name of the file to save</param>
/// <param name="student_name">Name of the student</param>
/// <param name="key">Encryption key used</param>
/// <param name="data">Data to save</param>
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file for writing: " << filename << std::endl;
        return;
    }

    // Get the current date
    std::time_t t = std::time(nullptr);
    std::tm tm = *std::localtime(&t);
    std::ostringstream date_stream;
    date_stream << std::put_time(&tm, "%Y-%m-%d");

    // Write data to the file
    file << "Student Name: " << student_name << "\n";
    file << "Date: " << date_stream.str() << "\n";
    file << "Key: " << key << "\n";
    file << "Data: " << data << "\n";
}

/// <summary>
/// Main function for encryption and decryption test.
/// </summary>
int main() {
    std::cout << "Encryption Decryption Test - By Samuel Rincon!" << std::endl;

    // File names
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    // Read source string from file
    const std::string source_string = read_file(file_name);

    // Encryption key
    const std::string key = "SamuelKey";

    // Get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // Encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save encrypted string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save decrypted string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    return 0;
}
