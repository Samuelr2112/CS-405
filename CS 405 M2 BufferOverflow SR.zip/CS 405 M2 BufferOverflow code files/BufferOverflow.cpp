// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <string>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // Constant account number that should remain unaltered
    const std::string account_number = "21122000";
    char user_input[20]; // User input buffer of size 20

    std::cout << "Enter a value (up to 19 characters): ";
    std::cin.get(user_input, sizeof(user_input)); // Limit input to 19 characters

    // Check if input was truncated due to length
    if (std::cin.gcount() == sizeof(user_input) - 1 && std::cin.peek() != '\n') {
        std::cout << "Warning: Input too long, truncated to 19 characters." << std::endl;
        // Clear excess characters
        std::cin.ignore(10000, '\n');
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}
