#include <iostream>
#include <stdexcept>
#include <exception>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "CustomException occurred!";
    }
};

// Function with standard exception throwing
bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception for demonstration purposes
    throw std::runtime_error("Standard exception from do_even_more_custom_application_logic!");

    return true; // Will not be reached due to exception
}

void do_custom_application_logic() {
    try {
        // Wrapping the call to do_even_more_custom_application_logic() with a try-catch block
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } catch (const std::exception& e) {
        // Catching the standard exception and displaying its message
        std::cout << "Exception caught in do_custom_application_logic: " << e.what() << std::endl;
    }

    // Throwing a custom exception for demonstration purposes
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl; // Will not be reached due to exception
}

float divide(float num, float den) {
    if (den == 0) {
        // Throwing a standard C++ exception for division by zero
        throw std::invalid_argument("Division by zero error!");
    }
    return num / den;
}

void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0;

    try {
        // Attempting the division and catching only divide-related exceptions
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    } catch (const std::invalid_argument& e) {
        // Catching the division by zero exception and displaying its message
        std::cout << "Exception caught in do_division: " << e.what() << std::endl;
    }
}

int main() {
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // Wrapping the main logic in a try-catch block for comprehensive exception handling
        do_division();
        do_custom_application_logic();
    } catch (const CustomException& e) {
        // Catching custom exceptions explicitly
        std::cout << "CustomException caught in main: " << e.what() << std::endl;
    } catch (const std::exception& e) {
        // Catching standard exceptions
        std::cout << "Standard exception caught in main: " << e.what() << std::endl;
    } catch (...) {
        // Catching any uncaught exceptions
        std::cout << "An unknown exception occurred in main!" << std::endl;
    }

    std::cout << "Program finished." << std::endl;
    return 0;
}
